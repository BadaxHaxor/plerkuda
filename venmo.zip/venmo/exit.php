<?php

header("Location: https://venmo.com/");

?>