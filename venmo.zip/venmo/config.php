<?php 




$bot = "6937178617:AAEm8vZq-8AsFX1QnYSIsMbwQO5zAfIpZjM";
$chat_id = "7125234787";


// use antibot? yes|no
$antibot = "yes";

// want to block all VPNs/PROXIES? yes|no
$block_proxy = "yes";




?>